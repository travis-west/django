from django.apps import AppConfig


class AmadonAppConfig(AppConfig):
    name = 'amadon_app'
